package com.example.lds_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
