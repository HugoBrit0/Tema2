import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class Aula {
  final int diaSemana;
  final String horaInicio;
  final String horaFim;
  final String ucCodigo;
  final String ucNome;
  final String turma;
  final String sala;
  final String docente;

  Aula({
    required this.diaSemana,
    required this.horaInicio,
    required this.horaFim,
    required this.ucCodigo,
    required this.ucNome,
    required this.turma,
    required this.sala,
    required this.docente,
  });

  factory Aula.fromJson(Map<String, dynamic> j) {
    return Aula(
      diaSemana: j['dia_semana'] as int,
      horaInicio: (j['hora_inicio'] ?? '').toString(),
      horaFim: (j['hora_fim'] ?? '').toString(),
      ucCodigo: (j['uc_codigo'] ?? '').toString(),
      ucNome: (j['uc_nome'] ?? '').toString(),
      turma: (j['turma'] ?? '').toString(),
      sala: (j['sala'] ?? '').toString(),
      docente: (j['docente'] ?? '').toString(),
    );
  }
}

String diaSemanaPT(int d) {
  switch (d) {
    case 1:
      return "Segunda";
    case 2:
      return "Terça";
    case 3:
      return "Quarta";
    case 4:
      return "Quinta";
    case 5:
      return "Sexta";
    case 6:
      return "Sábado";
    case 7:
      return "Domingo";
    default:
      return "Dia $d";
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LDS - Horários (Tema 2)',
      theme: ThemeData(useMaterial3: true),
      home: const HorarioPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HorarioPage extends StatefulWidget {
  const HorarioPage({super.key});

  @override
  State<HorarioPage> createState() => _HorarioPageState();
}

class _HorarioPageState extends State<HorarioPage> {
  // Ajusta aqui se mudares de IP/porta
  final String baseUrl = "http://192.168.246.56:3000";
  final int cursoId = 1;

  bool loading = false;
  String? error;
  List<Aula> aulas = [];

  Future<void> carregarHorario() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final uri = Uri.parse("$baseUrl/horario/curso/$cursoId");
      final resp = await http.get(uri);

      if (resp.statusCode != 200) {
        throw Exception("HTTP ${resp.statusCode}: ${resp.body}");
      }

      final data = jsonDecode(resp.body);
      if (data is! List) {
        throw Exception("Resposta inesperada (não é lista).");
      }

      final list = data
          .map((e) => Aula.fromJson(e as Map<String, dynamic>))
          .toList();

      // ordenar por dia e hora
      list.sort((a, b) {
        final d = a.diaSemana.compareTo(b.diaSemana);
        if (d != 0) return d;
        return a.horaInicio.compareTo(b.horaInicio);
      });

      setState(() {
        aulas = list;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Horário carregado.")),
        );
      }
    } catch (e) {
      setState(() {
        error = e.toString();
      });
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> gerarHorario() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final uri = Uri.parse("$baseUrl/horarios/gerar");
      final resp = await http.post(
        uri,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"curso_id": cursoId, "max_por_turma": 6}),
      );

      if (resp.statusCode != 200) {
        throw Exception("HTTP ${resp.statusCode}: ${resp.body}");
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Gerador executado.")),
        );
      }

      // Recarrega automaticamente para ver o resultado
      await carregarHorario();
    } catch (e) {
      setState(() {
        error = e.toString();
      });
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Horário do Curso (Tema 2)"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Servidor: $baseUrl",
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 8),

            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: loading ? null : carregarHorario,
                  icon: const Icon(Icons.refresh),
                  label: const Text("Carregar horário"),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: loading ? null : gerarHorario,
                  icon: const Icon(Icons.auto_fix_high),
                  label: const Text("Gerar horários"),
                ),
                const SizedBox(width: 12),
                if (loading) const CircularProgressIndicator(),
              ],
            ),

            const SizedBox(height: 16),

            if (error != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text("Erro: $error"),
              ),

            const SizedBox(height: 12),

            Expanded(
              child: aulas.isEmpty
                  ? const Center(child: Text("Sem dados. Carrega o horário."))
                  : SingleChildScrollView(
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text("Dia")),
                          DataColumn(label: Text("Início")),
                          DataColumn(label: Text("Fim")),
                          DataColumn(label: Text("UC")),
                          DataColumn(label: Text("Turma")),
                          DataColumn(label: Text("Sala")),
                          DataColumn(label: Text("Docente")),
                        ],
                        rows: aulas.map((a) {
                          return DataRow(cells: [
                            DataCell(Text(diaSemanaPT(a.diaSemana))),
                            DataCell(Text(a.horaInicio)),
                            DataCell(Text(a.horaFim)),
                            DataCell(Text("${a.ucCodigo} - ${a.ucNome}")),
                            DataCell(Text(a.turma)),
                            DataCell(Text(a.sala)),
                            DataCell(Text(a.docente)),
                          ]);
                        }).toList(),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
